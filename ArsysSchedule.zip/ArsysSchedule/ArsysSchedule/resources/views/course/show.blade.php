<table class="table table-bordered">
    <tr>
        <th>Unique ID</th>
        <td>{{ $item->uniqueid }}</td>
    </tr>
    <tr>
        <th>Pos Code</th>
        <td>{{ $item->pos_code }}</td>
    </tr>
    <tr>
        <th>Name</th>
        <td>{{ $item->title }}</td>
    </tr>
    <tr>
        <th>Department</th>
        <td>{{ $item->dept }}</td>
    </tr>
</table>
