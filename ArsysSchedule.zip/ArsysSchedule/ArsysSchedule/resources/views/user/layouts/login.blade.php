@include('user.includes.header')
@yield('content')
@include('user.includes.script')