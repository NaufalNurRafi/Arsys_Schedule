@include('user.includes.header')
@include('user.includes.navbar')
@yield('content')
@include('user.includes.script')