@include('dosen.includes.header')
@include('dosen.includes.navbar')
@yield('content')
@include('dosen.includes.script')