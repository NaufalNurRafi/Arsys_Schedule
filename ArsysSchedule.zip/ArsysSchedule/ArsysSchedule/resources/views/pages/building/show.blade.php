<table class="table table-bordered">
    <tr>
        <th>ID</th>
        <td>{{ $item->uniqueid }}</td>
    </tr>
    <tr>
        <th> Name</th>
        <td>{{ $item->name }}</td>
    </tr>
    <tr>
        <th>Abbreviation</th>
        <td>{{ $item->abbreviation }}</td>
    </tr>
    <tr>
        <th>Coordinate X</th>
        <td>{{ $item->coordinate_x }}</td>
    </tr>
    <tr>
        <th>Coordinate Y</th>
        <td>{{ $item->coordinate_y }}</td>
    </tr>
</table>
