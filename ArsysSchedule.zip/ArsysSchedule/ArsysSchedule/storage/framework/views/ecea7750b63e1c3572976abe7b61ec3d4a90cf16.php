<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-8">
                
            </div>
            <div class="col-4">
                <a type="submit" href="<?php echo e(route('course_offering.create')); ?>" class="btn btn-primary pull-right">Add Course Offering</a>
                <div class="clearfix"></div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Data Course Offering</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead class="text-primary">
                                    <th>
                                        ID
                                    </th>
                                    <th>
                                        Course Number
                                    </th>
                                    <th>
                                        Title
                                    </th>
                                    <th>
                                        Instructor
                                    </th>
                                    <!-- <th>
                                        Department
                                    </th> -->
                                    <th>
                                        Action
                                    </th>
                                </thead> 
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td>
                                                <?php echo e($item->uniqueid); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->course_nbr); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->title); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->instr_offr_id); ?> 
                                            </td>
                                            <!-- <td>
                                            
                                            </td> -->
                                            <td>
                                                <a href="#mymodal" data-remote="<?php echo e(route('course_offering.show', $item->uniqueid)); ?>"
                                                    data-toggle="modal" data-target="#mymodal" data-title=""
                                                    class="btn btn-info btn-sm">
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                                <a href="<?php echo e(route('course_offering.edit', $item->uniqueid)); ?>"
                                                    class="btn btn-primary btn-sm">
                                                    <i class="fa fa-pencil"></i>
                                                </a>
                                                <form action="<?php echo e(route('course_offering.destroy', $item->uniqueid)); ?>" method="post"
                                                    class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button class="btn btn-danger btn-sm">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td>
                                                Data tidak tersedia
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Downloads/ArsysSchedule/ArsysSchedule/resources/views/pages/course_offering/index.blade.php ENDPATH**/ ?>