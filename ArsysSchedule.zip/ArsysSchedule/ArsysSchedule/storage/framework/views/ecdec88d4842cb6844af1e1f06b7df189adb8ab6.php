<table class="table table-bordered">
    <tr>
        <th>ID</th>
        <td><?php echo e($item->uniqueid); ?></td>
    </tr>
    <tr>
        <th> Pos Code</th>
        <td><?php echo e($item->pos_code); ?></td>
    </tr>
    <tr>
        <th>Name</th>
        <td><?php echo e($item->fname); ?></td>
    </tr>
    <tr>
        <th>Dept</th>
        <td><?php echo e($item->dept); ?></td>
    </tr>
</table>
<?php /**PATH C:\laragon\www\ArsysSchedule\ArsysSchedule\resources\views/pages/staff/show.blade.php ENDPATH**/ ?>