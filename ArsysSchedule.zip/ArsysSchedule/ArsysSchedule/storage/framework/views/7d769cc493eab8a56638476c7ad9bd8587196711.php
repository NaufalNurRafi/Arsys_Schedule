<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('assets-real/css/bootstrap.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets-real/css/all.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets-real/css/fontawesome.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets-real/css/custom.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets-real/css/responsive.css')); ?>" rel="stylesheet" />
    <!-- font -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&family=Nunito&family=Oswald:wght@400;600;700&display=swap" rel="stylesheet"> 
    <title>Sistem Informasi Akademik</title>
  </head><?php /**PATH /Users/mac/Documents/Skripsi/sistem/sistem-informasi-akademik-kampus-laravel-master/resources/views/user/includes/header.blade.php ENDPATH**/ ?>