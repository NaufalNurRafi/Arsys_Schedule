<table class="table table-bordered">
    <tr>
        <th>ID</th>
        <td><?php echo e($item->uniqueid); ?></td>
    </tr>
    <tr>
        <th> Name</th>
        <td><?php echo e($item->name); ?></td>
    </tr>
    <tr>
        <th>Abbreviation</th>
        <td><?php echo e($item->abbreviation); ?></td>
    </tr>
    <tr>
        <th>Coordinate X</th>
        <td><?php echo e($item->coordinate_x); ?></td>
    </tr>
    <tr>
        <th>Coordinate Y</th>
        <td><?php echo e($item->coordinate_y); ?></td>
    </tr>
</table>
<?php /**PATH /Users/mac/Downloads/ArsysSchedule/ArsysSchedule/resources/views/pages/building/show.blade.php ENDPATH**/ ?>