<?php $__env->startSection('content'); ?>
<div id="jumbotron">
    <div class="container">
      <div class="row d-flex"> 
        <div class="col-md-7 text-white text-center align-self-center">
          <p class="mb-4">Arsys Schedule</p>
          <hr>
          <p>University Timetabling</p>
        </div>
        <div class="col-md-5">
          <div class="login">
            <h3 class="text-center">Login</h3>
            <?php if(session('status')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <form class="user" action="<?php echo e(route('login2')); ?>" method="post">
            <?php echo csrf_field(); ?>
              <div class="form-group">
                <input type="text" name="username" class="form-control form-control-user" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Nim/Email">
              </div>
              <div class="form-group">
                <input type="password" name="password" class="form-control form-control-user" id="exampleInputPassword" placeholder="Password">
              </div>
              <h3 class="text-center"><button type="submit" class="btn btn-primary">Login</button></h3>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
<!-- end jumbotron -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Documents/Skripsi/sistem/ArsysSchedule/resources/views/otentikasi/login.blade.php ENDPATH**/ ?>