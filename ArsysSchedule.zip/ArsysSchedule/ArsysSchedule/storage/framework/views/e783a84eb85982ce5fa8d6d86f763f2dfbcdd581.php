<table class="table table-bordered">
    <tr>
        <th>Unique ID</th>
        <td><?php echo e($item->uniqueid); ?></td>
    </tr>
    <tr>
        <th>Session ID</th>
        <td><?php echo e($item->session_id); ?></td>
    </tr>
    <tr>
        <th>Subject Area Abbreviation</th>
        <td><?php echo e($item->subject_area_abbreviation); ?></td>
    </tr>
    <tr>
        <th>Long Title</th>
        <td><?php echo e($item->long_title); ?></td>
    </tr>
    <tr>
        <th>Department Unique ID</th>
        <td><?php echo e($item->department_uniqueid); ?></td>
    </tr>
    <!-- Add other rows based on the columns in the subject_area table -->
</table>
<?php /**PATH /Users/mac/Downloads/ArsysSchedule/ArsysSchedule/resources/views/pages/subject_area/show.blade.php ENDPATH**/ ?>