<?php $__env->startSection('content'); ?>
    <div class="container">
        
        <?php if($errors->has('file')): ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('file')); ?></strong>
            </span>
        <?php endif; ?>

        
        <?php if($sukses = Session::get('sukses')): ?>
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo e($sukses); ?></strong>
            </div>
        <?php endif; ?>

        <button type="button" class="btn btn-primary mr-5" data-toggle="modal" data-target="#importExcel">
            IMPORT EXCEL
        </button>

        <!-- Import Excel -->
        <div class="modal fade" id="importExcel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <form method="post" action="/course/import_excel" enctype="multipart/form-data">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Import Excel</h5>
                        </div>
                        <div class="modal-body">
                            <?php echo e(csrf_field()); ?>


                            <label>Pilih file excel</label>
                            <div class="form-group">
                                <input type="file" name="file" required="required">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Import</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <a href="/course/export_excel" class="btn btn-success my-3" target="_blank">EXPORT EXCEL</a>

        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Data Subject Area</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead class="text-center">
                                    <th>No</th>
                                    <th>Course</th>
                                    <th>Itype</th>
                                    
                                    <th>Date Pattern</th>
                                    <th>Day</th>
                                    <th>Start Time</th>
                                    <th>End Time</th>
                                    <th>Room</th>
                                    <th >Instructor</th class="text-center">
                                    </tr>
            </thead>
            <tbody>
    <?php $i=1 ?>
    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="text-center">
        <td><?php echo e($i++); ?></td>
        <td><?php echo e($course->course); ?></td>
        <td><?php echo e($course->itype); ?></td>
       
        <td><?php echo e($course->date_pattern); ?></td>
        <td><?php echo e($course->day); ?></td>
        <td><?php echo e($course->start_time); ?></td>
        <td><?php echo e($course->end_time); ?></td>
        <td><?php echo e($course->room); ?></td>
        <td><?php echo e($course->instructor); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>

        </table>
    </div>
    <div class="pagination">
            <?php echo e($courses->links()); ?>

        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Downloads/ArsysSchedule/ArsysSchedule/resources/views/course.blade.php ENDPATH**/ ?>